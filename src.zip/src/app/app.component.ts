import { Component } from '@angular/core';
import { ServicesService } from './services.service';
import { Countries } from '../assets/university';
// import { map } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Countries and Available Universities';

  universities!: Countries[];
  // universitiesString!:String[]
  constructor(private service:ServicesService) {}
 


  ngOnInit(): void {
    // this.service.getApi().subscribe((data) => {
    //   this.universities = data;
    //   console.log(data)
    //  })

    //this is to get all data
  //   this.service.getApi().subscribe((res:Countries[]) => {
  //     this.universities = res
  //     this.universitiesString=this.universities.map((value)=>{
  //       return value.country
  //     })
      
  //     this.universitiesString.forEach((d)=>{
  //       console.log(d)
  //     })
  //  })


  //  this.service.getApi().subscribe((data) =>{
  //   this.universities.map(function(data){
  //     console.log(data.country)
  //   })
    
  //   })
  }
}
