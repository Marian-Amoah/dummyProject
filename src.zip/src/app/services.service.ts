import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Countries } from '../assets/university';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private httpUniversity:HttpClient) { }

  url = 'http://universities.hipolabs.com/search?country';

   // get all details
   getApi():Observable<Countries[]>{
    return this.httpUniversity.get<Countries[]>('http://universities.hipolabs.com/search?country') 
  }
}
